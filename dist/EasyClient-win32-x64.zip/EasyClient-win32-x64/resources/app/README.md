## Environment
Node.js and npm installed.

## How to run
Change the keystone ip and port in public/index.html    
npm install && npm start

This client will auth automaticlly every REST request.


