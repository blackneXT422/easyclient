import { Dispatcher } from 'flux';

class DispatcherClass extends Dispatcher {
}

const AppDispatcher = new DispatcherClass();

export default AppDispatcher;
